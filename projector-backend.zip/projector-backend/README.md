# Projector — backend

A Node.js + Express + MongoDB API for the Projector workforce prototype, with email/password sign-in (JWT) and role-based permissions enforced on the server. The redesigned frontend is included in `public/index.html`. The server hosts it, and it loads and saves through the API.

**Not part of the backend: AI agents.** That includes AI-to-AI reporting lines (an AI agent reporting to an AI lead, with a human at the top of every chain) and the simulated reporting cycle. AI agent profiles, AI credits, simulated AI runs and the AI assistant chat stay as a client-side simulation in each user's browser. Tasks can still be assigned to AI agents, and submissions made in an AI agent's name are stored like any other submission.

## Quick start

Requires Node 18.18+ and MongoDB 6+.

```bash
cp .env.example .env          # set JWT_SECRET to a long random string
npm install
npm start                     # http://localhost:4000
```

On first start with an empty database, the server seeds the sample workspace: 17 people, 6 projects, 24 tasks, requests, onboardings, goals and so on. Dates are shifted so the data always looks current. Every sample account uses the password in `DEFAULT_PASSWORD` (default `projector123`).

| Account | Role |
|---|---|
| olivia.chen@acme.demo | CEO |
| avery.lee@acme.demo | Employer (administrator) |
| maya.patel@acme.demo | Team Leader · Design |
| noah.williams@acme.demo | Team Leader · Engineering |
| lena.nguyen@acme.demo | Employee · Design |

Email addresses follow the pattern `first.last@acme.demo` for everyone in the directory.

With Docker:

```bash
JWT_SECRET=$(openssl rand -hex 32) docker compose up --build
```

Other commands:

- `npm run seed`: wipes the database and re-seeds the sample data.
- `npm test`: runs the API test suite against `mongodb://127.0.0.1:27017/projector_test`, a database the tests create and drop.
- `npm run dev`: starts the server and restarts it when files change.

## Configuration (`.env`)

| Variable | Default | Purpose |
|---|---|---|
| `MONGODB_URI` | `mongodb://127.0.0.1:27017/projector` | Database connection string |
| `JWT_SECRET` | random per start (dev only) | Signs session tokens. **Required in production.** |
| `JWT_EXPIRES` | `8h` | Session length |
| `DEFAULT_PASSWORD` | `projector123` | Password for seeded accounts and for accounts administrators create |
| `SEED_ON_EMPTY` | `true` | Seeds sample data when the database has no users |
| `ALLOW_DEMO_RESET` | `true` (off when `NODE_ENV=production`) | Enables `POST /api/admin/reset` |
| `CORS_ORIGIN` | empty (same origin only) | Comma-separated origins, if the frontend is hosted elsewhere |
| `PORT` | `4000` | HTTP port |

## API

All routes are under `/api`. Every route except `/health` and `/auth/login` needs `Authorization: Bearer <token>`. Errors come back as `{ "error": "message" }` with an appropriate status code:

- `400`: invalid input
- `401`: not signed in or session expired
- `403`: not allowed
- `404`: not found, or outside your visibility
- `409`: duplicate id, or a rule conflict (for example completing a task before its review is approved)

| Method | Route | Description |
|---|---|---|
| GET | `/health` | Liveness and database status |
| POST | `/auth/login` | `{ email, password }` → `{ token, user }` (rate-limited) |
| GET | `/auth/me` | The current user |
| POST | `/auth/password` | `{ current, next }`; minimum 8 characters |
| GET | `/bootstrap` | Everything the user can see, in one call (collections below plus `settings`) |
| GET | `/:collection` | List, filtered to the user's visibility |
| GET | `/:collection/:id` | Read one |
| POST | `/:collection` | Create; the client supplies `id` (letters, digits, `-`, `_`) |
| PATCH | `/:collection/:id` | Partial update; only fields that changed are checked and saved |
| DELETE | `/:collection/:id` | Administrators only |
| GET / PUT | `/settings` | Workspace switches; PUT is administrators only |
| GET / PUT | `/company` | Company profile (name, mission, values, contact details…); everyone can read it, only the CEO and Employer can change it |
| POST | `/people/:id/reset-password` | CEO or Employer sets someone's password back to `DEFAULT_PASSWORD` (no email is sent) |
| POST | `/admin/reset` | Restores the sample workspace; CEO or Employer, and only when enabled |

The collections are `people`, `projects`, `tasks`, `requests`, `meetings`, `documents`, `goals`, `automation`, `onboardings` and `activity`. Only fields defined in the schema are accepted (`src/models.js`). Mongo operators and keys like `__proto__` are stripped from input, and password hashes are never returned.

## Permissions (enforced in `src/policies.js`)

| Area | Who can see | Who can change |
|---|---|---|
| **Tasks** | CEO and Employer: all. Others: tasks in their department, plus tasks they created or are assigned to. | Creator, assignee, department lead or administrator. Anyone who can see a task can *add* to its review conversation and comments; neither can be edited or removed. |
| **Reviews** | Same as tasks | Only the assignee submits a new version (for an AI-assigned task, its reviewers do). Only the creator, department lead or an administrator can **approve**; the server records the signed-in reviewer as the approver. A task with submissions can't be marked Done until a version is approved. |
| **Requests** | CEO and Employer: all. Leads: their own requests plus requests sent to their department. Employees: their own. | Anyone can submit; the requester and `Pending` status are set by the server. Only the destination team lead or an administrator can accept, decline or ask for clarification. The requester can edit the brief while it is pending. |
| **Onboarding** | CEO and Employer: all. Leads: the onboardings assigned to them. Employees: their own. | Only the Employer starts, reassigns or activates an onboarding; the assigned lead completes the setup steps. |
| **People** | Everyone | CEO and Employer. New accounts get `DEFAULT_PASSWORD`; inactive accounts can't sign in. |
| **Projects** | Everyone | Anyone except Employees can create. Owner, department lead or administrator can edit. |
| **Meetings / documents** | Everyone | Anyone can create. Host, author, leads or administrators can edit. |
| **Company profile** | Everyone (the page itself is shown to the CEO and Employer only) | CEO and Employer |
| **Goals, automation, settings** | Everyone | Administrators (anyone can propose a goal) |
| **Activity** | Everyone (latest 60) | Anyone can add an entry; existing entries can't be changed |

## How the frontend uses the API

`public/index.html` is the redesigned single-file app. It works in two ways:

- **Served by this backend:** it shows the branded sign-in screen (one login for every role, show/hide password, "Keep me signed in", password help and one-click sample accounts). After sign-in it loads `/bootstrap`, and the user's role and permissions come from their account.
- **Opened directly as a file:** it runs as before, as a local demo with a role picker and data saved in the browser.

Saving works by comparison. After each change the page compares its data with the last version it got from the server, then sends the matching `POST`, `PATCH` or `DELETE` calls. If the server rejects a change, the page shows the server's message and reloads the server's data, so nothing can be saved past the permission checks. Every 15 seconds, and whenever the tab regains focus, it fetches the latest data so teammates see each other's work. It never does this while a form, dialog or menu is open.

Simultaneous edits are last-write-wins, decided field by field. If you need strict conflict detection, add an `updatedAt` check to the `PATCH` route.

## Production notes

- Set `NODE_ENV=production`, a strong `JWT_SECRET`, and a non-default `DEFAULT_PASSWORD`. Ask people to change their password after first sign-in.
- Run behind HTTPS (a reverse proxy or load balancer). The app sets `trust proxy` and secure headers through Helmet.
- Sessions are stateless JWTs kept in the browser's `localStorage`. For stricter setups, move them to httpOnly cookies and add refresh tokens, or plug in SSO in `src/auth.js`.
- No emails are sent, and there are no file uploads beyond small preview images embedded in review submissions (requests are limited to 3 MB).

## Project layout

```
src/
  server.js          start-up, DB connection, seed-on-empty
  app.js             Express app, security headers, routing
  config.js          environment settings
  auth.js            login, JWT middleware, password change
  models.js          Mongoose schemas
  policies.js        role-based read scopes and write rules
  routes/resources.js  generic CRUD for each collection
  routes/workspace.js  bootstrap, settings, demo reset
  seed/              sample data (relative dates) and seeder
public/index.html    redesigned frontend
test/api.test.js     API tests (node:test + supertest)
```
