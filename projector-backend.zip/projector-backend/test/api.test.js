'use strict';
// Run with a disposable database: MONGODB_URI=mongodb://127.0.0.1:27017/projector_test npm test
process.env.MONGODB_URI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/projector_test';
process.env.JWT_SECRET = process.env.JWT_SECRET || 'test-secret';
process.env.BCRYPT_ROUNDS = '4';

const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const mongoose = require('mongoose');
const request = require('supertest');
const config = require('../src/config');
const { createApp } = require('../src/app');
const { seedDatabase } = require('../src/seed/seed');

let app;
const tokens = {};
const as = (who) => ({ Authorization: `Bearer ${tokens[who]}` });
const login = async (email, password = config.defaultPassword) => request(app).post('/api/auth/login').send({ email, password });

before(async () => {
  await mongoose.connect(config.mongoUri);
  await Promise.all(Object.values(mongoose.models).map((m) => m.init()));
  await seedDatabase({ drop: true });
  app = createApp();
  for (const [k, email] of Object.entries({ ceo: 'olivia.chen@acme.demo', employer: 'avery.lee@acme.demo', lead: 'maya.patel@acme.demo', engLead: 'noah.williams@acme.demo', employee: 'lena.nguyen@acme.demo' })) {
    const r = await login(email);
    assert.equal(r.status, 200, `login ${email}`);
    tokens[k] = r.body.token;
  }
});
after(async () => { await mongoose.connection.dropDatabase(); await mongoose.disconnect(); });

test('health and auth basics', async () => {
  assert.equal((await request(app).get('/api/health')).body.ok, true);
  assert.equal((await request(app).get('/api/tasks')).status, 401);
  assert.equal((await login('lena.nguyen@acme.demo', 'nope')).status, 401);
  assert.equal((await login('jordan@nowhere.demo')).status, 401);
  const me = await request(app).get('/api/auth/me').set(as('employee'));
  assert.equal(me.body.user.id, 'U9');
  assert.equal(me.body.user.passwordHash, undefined, 'password hash never leaves the server');
});

test('inactive (onboarding) accounts cannot sign in', async () => {
  assert.equal((await login('pending@acme.demo')).status, 403);
});

test('bootstrap is scoped by role', async () => {
  const all = await request(app).get('/api/bootstrap').set(as('ceo'));
  const mine = await request(app).get('/api/bootstrap').set(as('employee'));
  assert.equal(all.body.tasks.length, 24);
  assert.ok(mine.body.tasks.length < all.body.tasks.length);
  assert.ok(mine.body.tasks.every((t) => t.department === 'Design' || t.assigneeId === 'U9' || t.createdBy === 'U9'));
  assert.equal(mine.body.onboardings.length, 0);
  assert.equal((await request(app).get('/api/tasks/T2').set(as('employee'))).status, 404, 'Engineering task hidden from a Design employee');
});

test('task create, duplicate ids and edit permissions', async () => {
  const body = { id: 'TQA1', title: 'QA task', status: 'To do', priority: 'High', department: 'Design', assigneeId: 'U9', createdBy: 'U1' };
  const created = await request(app).post('/api/tasks').set(as('employee')).send(body);
  assert.equal(created.status, 201);
  assert.equal(created.body.createdBy, 'U9', 'employees cannot create on behalf of someone else');
  assert.equal((await request(app).post('/api/tasks').set(as('employee')).send(body)).status, 409);
  // Engineering lead cannot see or edit a Design task they are not part of
  assert.equal((await request(app).patch('/api/tasks/TQA1').set(as('engLead')).send({ title: 'x' })).status, 404);
  // Unknown fields and operators are ignored
  const p = await request(app).patch('/api/tasks/TQA1').set(as('employee')).send({ title: 'QA task v2', $where: '1', passwordHash: 'x' });
  assert.equal(p.status, 200);
  assert.equal(p.body.title, 'QA task v2');
});

test('review rules: assignee submits, only reviewers approve, done requires approval', async () => {
  const t = (await request(app).get('/api/tasks/HUMAN-DEMO-1').set(as('employee'))).body;
  // Assignee cannot approve their own work
  let r = await request(app).patch('/api/tasks/HUMAN-DEMO-1').set(as('employee')).send({ reviewState: 'approved' });
  assert.equal(r.status, 403);
  // Cannot complete with an unapproved submission
  r = await request(app).patch('/api/tasks/HUMAN-DEMO-1').set(as('lead')).send({ status: 'Done' });
  assert.equal(r.status, 409);
  // Conversation is append-only
  r = await request(app).patch('/api/tasks/HUMAN-DEMO-1').set(as('employee')).send({ reviewThread: [] });
  assert.equal(r.status, 403);
  r = await request(app).patch('/api/tasks/HUMAN-DEMO-1').set(as('employee')).send({ reviewThread: [...t.reviewThread, { by: 'U9', role: 'assignee', text: 'Ready!' }] });
  assert.equal(r.status, 200);
  // The department lead approves
  r = await request(app).patch('/api/tasks/HUMAN-DEMO-1').set(as('lead')).send({ reviewState: 'approved', status: 'Done', progress: 100, approvedBy: 'U1' });
  assert.equal(r.status, 200);
  assert.equal(r.body.approvedBy, 'U4', 'approver is always the signed-in reviewer');
});

test('requests: requester fields forced, decisions limited to destination lead', async () => {
  const r = await request(app).post('/api/requests').set(as('employee')).send({ id: 'RQA1', title: 'Need icons', targetDepartment: 'Engineering', status: 'Accepted', requesterId: 'U1' });
  assert.equal(r.status, 201);
  assert.equal(r.body.status, 'Pending');
  assert.equal(r.body.requesterId, 'U9');
  assert.equal((await request(app).patch('/api/requests/RQA1').set(as('employee')).send({ status: 'Accepted' })).status, 403);
  assert.equal((await request(app).patch('/api/requests/RQA1').set(as('lead')).send({ status: 'Accepted' })).status, 404, 'Design lead cannot see an Engineering request');
  assert.equal((await request(app).patch('/api/requests/RQA1').set(as('engLead')).send({ status: 'Accepted' })).status, 200);
});

test('people and onboarding administration', async () => {
  assert.equal((await request(app).post('/api/people').set(as('lead')).send({ id: 'UQA1', name: 'X', email: 'x@acme.demo' })).status, 403);
  const p = await request(app).post('/api/people').set(as('employer')).send({ id: 'UQA1', name: 'New Hire', email: 'new.hire@acme.demo', role: 'Employee', department: 'Design' });
  assert.equal(p.status, 201);
  assert.equal((await login('new.hire@acme.demo')).status, 200, 'new accounts can sign in with the default password');
  const ob = (await request(app).get('/api/bootstrap').set(as('ceo'))).body.onboardings.find((o) => o.leadId === 'U5');
  assert.equal((await request(app).patch(`/api/onboardings/${ob.id}`).set(as('lead')).send({ stage: 'Collecting requirements' })).status, 404);
  assert.equal((await request(app).patch(`/api/onboardings/${ob.id}`).set(as('employer')).send({ stage: 'Collecting requirements' })).status, 200);
});

test('activity is append-only and settings are admin-only', async () => {
  assert.equal((await request(app).post('/api/activity').set(as('employee')).send({ id: 'ACTQA', name: 'Lena', action: 'tested' })).status, 201);
  assert.equal((await request(app).patch('/api/activity/ACTQA').set(as('ceo')).send({ action: 'edited' })).status, 403);
  assert.equal((await request(app).put('/api/settings').set(as('employee')).send({ audit: false })).status, 403);
  assert.equal((await request(app).put('/api/settings').set(as('employer')).send({ audit: false })).body.audit, false);
});

test('password change', async () => {
  assert.equal((await request(app).post('/api/auth/password').set(as('employee')).send({ current: 'wrong', next: 'longenough1' })).status, 400);
  assert.equal((await request(app).post('/api/auth/password').set(as('employee')).send({ current: config.defaultPassword, next: 'short' })).status, 400);
  assert.equal((await request(app).post('/api/auth/password').set(as('employee')).send({ current: config.defaultPassword, next: 'new-password-1' })).status, 200);
  assert.equal((await login('lena.nguyen@acme.demo', 'new-password-1')).status, 200);
});

test('company profile: everyone reads, only CEO/Employer edit, input validated', async () => {
  const boot = await request(app).get('/api/bootstrap').set(as('employee'));
  assert.equal(boot.body.company.name, 'Acme Corporation');
  assert.equal((await request(app).put('/api/company').set(as('lead')).send({ name: 'Hacked' })).status, 403);
  const ok = await request(app).put('/api/company').set(as('ceo')).send({ name: 'Acme Group', values: ['One', 'Two'], passwordHash: 'x' });
  assert.equal(ok.status, 200);
  assert.equal(ok.body.name, 'Acme Group');
  assert.deepEqual(ok.body.values, ['One', 'Two']);
  assert.equal((await request(app).put('/api/company').set(as('employer')).send({ website: 'javascript:alert(1)' })).status, 400);
});

test('administrators can reset a password to the default', async () => {
  assert.equal((await request(app).post('/api/people/U10/reset-password').set(as('lead'))).status, 403);
  assert.equal((await request(app).post('/api/people/U9/reset-password').set(as('employer'))).status, 200);
  assert.equal((await login('lena.nguyen@acme.demo')).status, 200);
});
