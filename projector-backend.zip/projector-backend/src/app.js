'use strict';
const path = require('path');
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const mongoose = require('mongoose');
const config = require('./config');
const auth = require('./auth');
const resources = require('./routes/resources');
const workspace = require('./routes/workspace');
const { errorHandler, HttpError } = require('./errors');

function createApp() {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', 1);

  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        // The single-file frontend uses inline scripts/styles.
        scriptSrc: ["'self'", "'unsafe-inline'"],
        scriptSrcAttr: ["'none'"],
        styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
        fontSrc: ["'self'", 'https://fonts.gstatic.com', 'data:'],
        imgSrc: ["'self'", 'data:', 'blob:'],
        connectSrc: ["'self'"],
      },
    },
  }));
  if (config.corsOrigin) {
    app.use(cors({ origin: config.corsOrigin.split(',').map((s) => s.trim()), credentials: false }));
  }
  app.use(express.json({ limit: '3mb' }));

  const api = express.Router();
  api.use(rateLimit({ windowMs: 60 * 1000, limit: 600, standardHeaders: true, legacyHeaders: false }));
  api.get('/health', (_req, res) => res.json({ ok: true, db: mongoose.connection.readyState === 1, service: 'projector-api' }));
  api.use('/auth', auth.router);
  api.use(auth.requireAuth);
  api.use(workspace.router);
  api.use(resources.router);
  api.use((_req, _res, next) => next(new HttpError(404, 'Unknown API route.')));
  app.use('/api', api);

  const pub = path.join(__dirname, '..', 'public');
  app.use(express.static(pub, { index: 'index.html', maxAge: config.isProd ? '1h' : 0 }));
  app.get('*', (_req, res) => res.sendFile(path.join(pub, 'index.html')));

  app.use(errorHandler);
  return app;
}

module.exports = { createApp };
