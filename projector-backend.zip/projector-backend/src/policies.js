'use strict';
/**
 * Role-based access rules, mirroring the prototype's UI rules but enforced on the server.
 * Each policy may define:
 *   scope(user)                      -> Mongo filter for what the user can read
 *   prepare(user, doc)               -> server-controlled fields on create
 *   create(user, doc)                -> throw to deny a create
 *   update(user, old, next, changed) -> throw to deny an update (changed = list of modified fields)
 *   remove(user, old)                -> throw to deny a delete (default: administrators only)
 */
const { HttpError } = require('./errors');

const isAdmin = (u) => u.role === 'CEO' || u.role === 'Employer';
const isLeader = (u) => u.role === 'Team Leader';
const deny = (msg, status = 403) => { throw new HttpError(status, msg); };
const today = () => new Date().toISOString().slice(0, 10);
const stable = (v) => JSON.stringify(v, (_k, val) => (val && typeof val === 'object' && !Array.isArray(val)
  ? Object.keys(val).sort().reduce((o, k) => { o[k] = val[k]; return o; }, {}) : val));
const appendOnly = (oldArr = [], nextArr = []) => Array.isArray(nextArr) && nextArr.length >= oldArr.length
  && stable(oldArr) === stable(nextArr.slice(0, oldArr.length));
const adminOnly = (what) => (u) => { if (!isAdmin(u)) deny(`Only administrators can change ${what}.`); };

const people = {
  scope: () => ({}),
  create: adminOnly('people'),
  update(u, old, _next, changed) {
    if (isAdmin(u)) return;
    if (old.id === u.id && changed.every((k) => k === 'online')) return;
    deny('Only administrators can edit employee profiles.');
  },
};

const projects = {
  scope: () => ({}),
  create(u) { if (u.role === 'Employee') deny('Project creation is limited to leads and administrators.'); },
  prepare(u, d) { if (!d.ownerId) d.ownerId = u.id; },
  update(u, old) {
    if (isAdmin(u) || old.ownerId === u.id || (isLeader(u) && old.department === u.department)) return;
    deny('Only the project owner, its department lead or an administrator can edit this project.');
  },
};

const canEditTask = (u, t) => isAdmin(u) || t.createdBy === u.id || t.assigneeId === u.id || (isLeader(u) && t.department === u.department);
const canReviewTask = (u, t) => isAdmin(u) || t.createdBy === u.id || (isLeader(u) && t.department === u.department);

const tasks = {
  scope: (u) => (isAdmin(u) ? {} : { $or: [{ createdBy: u.id }, { assigneeId: u.id }, { department: u.department }] }),
  prepare(u, d) {
    // Leads and admins may create work on behalf of a requester (e.g. accepting a request).
    if (!d.createdBy || !(isAdmin(u) || isLeader(u))) d.createdBy = u.id;
    d.reviewState = 'open'; d.submissions = []; d.approvedBy = '';
    if (!Array.isArray(d.reviewThread)) d.reviewThread = [];
  },
  update(u, old, next, changed) {
    const editor = canEditTask(u, old);
    for (const k of changed) {
      if (k === 'reviewThread' || k === 'notes') {
        if (!appendOnly(old[k], next[k])) deny('Conversation history can only be added to, not rewritten.');
      } else if (!editor) {
        deny('You can view this task, but only its creator, assignee, department lead or an administrator can change it.');
      }
    }
    if (changed.includes('submissions')) {
      if ((next.submissions || []).length < (old.submissions || []).length) deny('Submitted versions cannot be removed.');
      if ((next.submissions || []).length > (old.submissions || []).length) {
        const aiAssignee = String(old.assigneeId || '').startsWith('A');
        const allowed = aiAssignee ? canReviewTask(u, old) : (old.assigneeId === u.id || isAdmin(u));
        if (!allowed) deny('Only the assigned employee can submit a deliverable for this task.');
      }
    }
    if (next.reviewState === 'approved' && old.reviewState !== 'approved' && !canReviewTask(u, old)) {
      deny('Only the task creator, the department lead or an administrator can approve work.');
    }
    if (changed.includes('approvedBy') && next.approvedBy && next.approvedBy !== u.id) next.approvedBy = u.id;
    if (next.status === 'Done' && old.status !== 'Done' && (next.submissions || []).length && next.reviewState !== 'approved') {
      deny('Approve the submitted version in the review room before marking this task done.', 409);
    }
  },
};

const requests = {
  scope(u) {
    if (isAdmin(u)) return {};
    const mine = [{ requesterId: u.id }, { owner: u.name }];
    return { $or: isLeader(u) ? [...mine, { targetDepartment: u.department }] : mine };
  },
  prepare(u, d) {
    d.requesterId = u.id; d.status = 'Pending'; d.created = today(); d.assigneeId = ''; d.taskId = '';
    if (!d.owner) d.owner = u.name;
  },
  update(u, old, _next, changed) {
    const decider = isAdmin(u) || (isLeader(u) && old.targetDepartment === u.department);
    const decisionFields = ['status', 'assigneeId', 'taskId'];
    if (changed.some((k) => decisionFields.includes(k)) && !decider) {
      deny('Only the destination team lead or an administrator can decide on this request.');
    }
    const briefChanges = changed.filter((k) => !decisionFields.includes(k));
    if (briefChanges.length && !decider && !(old.requesterId === u.id && old.status === 'Pending')) {
      deny('Only the requester can edit a pending request brief.');
    }
  },
};

const meetings = {
  scope: () => ({}),
  prepare(u, d) { if (!isAdmin(u) || !d.hostId) d.hostId = u.id; },
  update(u, old) { if (!(isAdmin(u) || old.hostId === u.id)) deny('Only the host or an administrator can edit this meeting.'); },
};

const documents = {
  scope: () => ({}),
  prepare(u, d) { d.createdBy = u.id; d.updated = today(); },
  update(u, old, next) {
    if (!(isAdmin(u) || isLeader(u) || old.createdBy === u.id)) deny('Only the author, team leads or administrators can edit this document.');
    next.updated = today();
  },
};

const goals = { scope: () => ({}), update: adminOnly('goals') };
const automation = { scope: () => ({}), create: adminOnly('automation rules'), update: adminOnly('automation rules') };

const onboardings = {
  scope(u) {
    if (isAdmin(u)) return {};
    return isLeader(u) ? { leadId: u.id } : { profileId: u.id };
  },
  create(u) { if (u.role !== 'Employer') deny('Only Employers can start an onboarding.'); },
  update(u, old, next, changed) {
    if (u.role === 'Employer') return;
    if (!(isLeader(u) && old.leadId === u.id)) deny('Only the assigned setup owner or the Employer can update this onboarding.');
    if (changed.includes('leadId')) deny('Only the Employer can reassign setup ownership.');
    if (next.stage === 'Active' && old.stage !== 'Active') deny('Only the Employer can activate a new teammate.');
  },
};

const activity = {
  scope: () => ({}),
  prepare(u, d) { d.actorId = u.id; d.when = new Date(); },
  update: () => deny('Activity history is read-only.'),
  remove: () => deny('Activity history is read-only.'),
};

module.exports = {
  isAdmin, isLeader, stable,
  policies: { people, projects, tasks, requests, meetings, documents, goals, automation, onboardings, activity },
};
