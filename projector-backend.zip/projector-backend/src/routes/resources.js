'use strict';
const express = require('express');
const bcrypt = require('bcryptjs');
const config = require('../config');
const models = require('../models');
const { policies, stable } = require('../policies');
const { HttpError, wrap } = require('../errors');

/** Collection name (as used by the frontend) -> Mongoose model. */
const COLLECTIONS = {
  people: models.User,
  projects: models.Project,
  tasks: models.Task,
  requests: models.Request,
  meetings: models.Meeting,
  documents: models.Document,
  goals: models.Goal,
  automation: models.Automation,
  onboardings: models.Onboarding,
  activity: models.Activity,
};
const SORT = { activity: { when: -1 }, tasks: { createdAt: -1 }, requests: { createdAt: -1 }, onboardings: { createdAt: -1 } };
const LIMIT = { activity: 60 };
const ID_RE = /^[A-Za-z0-9_-]{1,64}$/;

/** Removes Mongo operators and prototype-polluting keys from client JSON. */
function clean(value, depth = 0) {
  if (depth > 12) return undefined;
  if (Array.isArray(value)) return value.map((v) => clean(v, depth + 1));
  if (value && typeof value === 'object') {
    const out = {};
    for (const [k, v] of Object.entries(value)) {
      if (k.startsWith('$') || k.includes('.') || k === '__proto__' || k === 'constructor' || k === 'prototype') continue;
      out[k] = clean(v, depth + 1);
    }
    return out;
  }
  return value;
}

function pickWritable(Model, body) {
  const src = clean(body || {});
  const out = {};
  for (const f of Model.writable) if (f in src) out[f] = src[f];
  return out;
}

function scoped(name, user, extra = {}) {
  const scope = policies[name].scope ? policies[name].scope(user) : {};
  return Object.keys(scope).length ? { $and: [scope, extra] } : extra;
}

async function listFor(name, user) {
  const Model = COLLECTIONS[name];
  let q = Model.find(scoped(name, user)).sort(SORT[name] || { createdAt: 1 });
  if (LIMIT[name]) q = q.limit(LIMIT[name]);
  const docs = await q;
  return docs.map((d) => present(name, d));
}

const ago = (date) => {
  const s = Math.max(0, (Date.now() - new Date(date).getTime()) / 1000);
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.floor(s / 60)} min ago`;
  if (s < 86400) return `${Math.floor(s / 3600)} h ago`;
  return `${Math.floor(s / 86400)} d ago`;
};
function present(name, doc) {
  const json = doc.toJSON();
  if (name === 'activity') json.at = ago(json.when);
  return json;
}

const router = express.Router();

router.param('collection', (req, _res, next, name) => {
  if (!Object.prototype.hasOwnProperty.call(COLLECTIONS, name)) return next(new HttpError(404, 'Unknown resource.'));
  req.collection = name; req.Model = COLLECTIONS[name]; req.policy = policies[name];
  next();
});

router.get('/:collection', wrap(async (req, res) => {
  res.json(await listFor(req.collection, req.user));
}));

router.get('/:collection/:id', wrap(async (req, res) => {
  const doc = await req.Model.findOne(scoped(req.collection, req.user, { id: String(req.params.id) }));
  if (!doc) throw new HttpError(404, 'Not found.');
  res.json(present(req.collection, doc));
}));

router.post('/:collection', wrap(async (req, res) => {
  const { Model, policy, user } = req;
  const id = String(req.body?.id || '');
  if (!ID_RE.test(id)) throw new HttpError(400, 'A valid id (letters, numbers, - or _) is required.');
  const data = { ...pickWritable(Model, req.body), id };
  if (policy.prepare) policy.prepare(user, data);
  if (policy.create) policy.create(user, data);
  if (req.collection === 'people') {
    data.passwordHash = await bcrypt.hash(config.defaultPassword, config.bcryptRounds);
  }
  const doc = await Model.create(data);
  res.status(201).json(present(req.collection, doc));
}));

router.patch('/:collection/:id', wrap(async (req, res) => {
  const { Model, policy, user, collection } = req;
  const doc = await Model.findOne(scoped(collection, user, { id: String(req.params.id) }));
  if (!doc) throw new HttpError(404, 'Not found, or you do not have access to it.');
  const old = doc.toObject();
  const incoming = pickWritable(Model, req.body);
  const next = { ...old, ...incoming };
  const changed = Object.keys(incoming).filter((k) => stable(old[k] ?? null) !== stable(incoming[k] ?? null));
  if (!changed.length) return res.json(present(collection, doc));
  if (policy.update) policy.update(user, old, next, changed);
  for (const k of new Set([...changed, 'updated', 'approvedBy'].filter((k) => Model.writable.includes(k) && next[k] !== old[k]))) {
    doc.set(k, next[k]);
    doc.markModified(k);
  }
  await doc.save();
  res.json(present(collection, doc));
}));

router.delete('/:collection/:id', wrap(async (req, res) => {
  const { Model, policy, user, collection } = req;
  const doc = await Model.findOne(scoped(collection, user, { id: String(req.params.id) }));
  if (!doc) throw new HttpError(404, 'Not found.');
  if (policy.remove) policy.remove(user, doc.toObject());
  else if (!['CEO', 'Employer'].includes(user.role)) throw new HttpError(403, 'Only administrators can delete records.');
  if (collection === 'people' && doc.id === user.id) throw new HttpError(400, 'You cannot delete your own account.');
  await doc.deleteOne();
  res.status(204).end();
}));

module.exports = { router, listFor, COLLECTIONS };
