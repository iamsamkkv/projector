'use strict';
const express = require('express');
const config = require('../config');
const bcrypt = require('bcryptjs');
const { Settings, Company, User } = require('../models');
const { listFor, COLLECTIONS } = require('./resources');
const { requireRole } = require('../auth');
const { HttpError, wrap } = require('../errors');
const { seedDatabase } = require('../seed/seed');

const router = express.Router();

async function getSettings() {
  return (await Settings.findOne({ id: 'workspace' })) || Settings.create({ id: 'workspace' });
}

async function getCompany() {
  return (await Company.findOne({ id: 'company' })) || Company.create({ id: 'company', name: 'Our company' });
}
const plainCompany = (c) => { const j = c.toJSON(); delete j.id; delete j.createdAt; delete j.updatedAt; return j; };

/** Everything the signed-in user is allowed to see, in one round trip. */
router.get('/bootstrap', wrap(async (req, res) => {
  const names = Object.keys(COLLECTIONS);
  const lists = await Promise.all(names.map((n) => listFor(n, req.user)));
  const out = { user: req.user.toJSON(), settings: (await getSettings()).toJSON(), company: plainCompany(await getCompany()) };
  names.forEach((n, i) => { out[n] = lists[i]; });
  delete out.settings.id; delete out.settings.createdAt; delete out.settings.updatedAt;
  res.json(out);
}));

router.get('/settings', wrap(async (_req, res) => res.json((await getSettings()).toJSON())));

router.put('/settings', requireRole('CEO', 'Employer'), wrap(async (req, res) => {
  const s = await getSettings();
  for (const k of ['approvals', 'audit', 'alerts']) if (typeof req.body?.[k] === 'boolean') s[k] = req.body[k];
  await s.save();
  res.json(s.toJSON());
}));

router.get('/company', wrap(async (_req, res) => res.json(plainCompany(await getCompany()))));

/** Company profile — CEO and Employer only. */
router.put('/company', requireRole('CEO', 'Employer'), wrap(async (req, res) => {
  const c = await getCompany();
  for (const k of Company.writable) {
    if (!(k in (req.body || {}))) continue;
    const v = req.body[k];
    if (k === 'values') c.values = Array.isArray(v) ? v.map((x) => String(x)).filter(Boolean) : [];
    else if (typeof v === 'string') c[k] = v;
  }
  await c.save();
  res.json(plainCompany(c));
}));

/** Administrators reset a person's password to the workspace default (no email is sent). */
router.post('/people/:id/reset-password', requireRole('CEO', 'Employer'), wrap(async (req, res) => {
  const user = await User.findOne({ id: String(req.params.id) });
  if (!user) throw new HttpError(404, 'Person not found.');
  user.passwordHash = await bcrypt.hash(config.defaultPassword, config.bcryptRounds);
  await user.save();
  res.json({ ok: true });
}));

/** Restores the original sample workspace (demo environments only). */
router.post('/admin/reset', requireRole('CEO', 'Employer'), wrap(async (_req, res) => {
  if (!config.allowDemoReset) throw new HttpError(403, 'Workspace reset is disabled on this server.');
  await seedDatabase({ drop: true });
  res.json({ ok: true });
}));

module.exports = { router };
