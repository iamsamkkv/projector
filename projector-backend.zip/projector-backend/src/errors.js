'use strict';
class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

function errorHandler(err, _req, res, _next) {
  if (err.type === 'entity.too.large') return res.status(413).json({ error: 'Payload too large.' });
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Malformed JSON body.' });
  if (err.name === 'ValidationError') {
    const first = Object.values(err.errors)[0];
    return res.status(400).json({ error: first ? `Invalid ${first.path}: ${first.message}` : 'Validation failed.' });
  }
  if (err.name === 'CastError') return res.status(400).json({ error: `Invalid value for ${err.path}.` });
  if (err.code === 11000) {
    const field = Object.keys(err.keyPattern || {})[0] || 'id';
    return res.status(409).json({ error: `A record with this ${field} already exists.` });
  }
  const status = err.status || 500;
  if (status >= 500) console.error(err);
  res.status(status).json({ error: status >= 500 ? 'Something went wrong on the server.' : err.message });
}

const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

module.exports = { HttpError, errorHandler, wrap };
