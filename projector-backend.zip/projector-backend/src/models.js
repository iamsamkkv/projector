'use strict';
const mongoose = require('mongoose');
const { Schema } = mongoose;
const Mixed = Schema.Types.Mixed;

const ID = { type: String, required: true, unique: true, match: /^[A-Za-z0-9_-]{1,64}$/ };
const str = (max = 300, extra = {}) => ({ type: String, trim: true, maxlength: max, default: '', ...extra });
const date = { type: String, default: '', match: /^(\d{4}-\d{2}-\d{2})?$/ };

function define(name, fields, { hidden = [] } = {}) {
  const schema = new Schema({ id: ID, ...fields }, { timestamps: true, minimize: false });
  schema.set('toJSON', {
    transform: (_doc, ret) => {
      delete ret._id; delete ret.__v;
      for (const h of hidden) delete ret[h];
      return ret;
    },
  });
  const model = mongoose.model(name, schema);
  // Fields a client may write (everything except id, server timestamps and hidden fields).
  model.writable = Object.keys(fields).filter((f) => !hidden.includes(f));
  return model;
}

const ROLES = ['CEO', 'Employer', 'Team Leader', 'Employee'];
const TASK_STATUS = ['To do', 'In progress', 'In review', 'Blocked', 'Done'];
const PRIORITY = ['Low', 'Medium', 'High', 'Urgent'];

const User = define('User', {
  name: str(120, { required: true }),
  email: { type: String, required: true, unique: true, lowercase: true, trim: true, maxlength: 200, match: /^[^\s@]+@[^\s@]+\.[^\s@]+$/ },
  passwordHash: { type: String, default: '' },
  role: { type: String, enum: ROLES, default: 'Employee' },
  title: str(120),
  department: str(80),
  online: { type: Boolean, default: false },
  active: { type: Boolean, default: true },
}, { hidden: ['passwordHash'] });

const Project = define('Project', {
  name: str(160, { required: true }),
  department: str(80),
  progress: { type: Number, min: 0, max: 100, default: 0 },
  ownerId: str(64),
  due: date,
  description: str(4000),
});

const Task = define('Task', {
  title: str(200, { required: true }),
  description: str(8000),
  assigneeId: str(64),
  createdBy: str(64),
  projectId: str(64),
  department: str(80),
  priority: { type: String, enum: PRIORITY, default: 'Medium' },
  status: { type: String, enum: TASK_STATUS, default: 'To do' },
  type: { type: String, enum: ['Task', 'Story', 'Bug'], default: 'Task' },
  epic: str(40), sprint: str(40), release: str(40),
  points: { type: Number, min: 0, max: 1000, default: 0 },
  progress: { type: Number, min: 0, max: 100, default: 0 },
  start: date, due: date,
  notes: { type: [Mixed], default: [] },
  subtasks: { type: [Mixed], default: [] },
  logged: { type: Number, min: 0, default: 0 },
  dependencies: { type: [String], default: [] },
  watching: { type: Boolean, default: false },
  reviewState: { type: String, enum: ['open', 'in_review', 'changes_requested', 'approved'], default: 'open' },
  submissions: { type: [Mixed], default: [] },
  reviewThread: { type: [Mixed], default: [] },
  approvedBy: str(64),
});

const Request = define('Request', {
  title: str(200, { required: true }),
  owner: str(120),
  requesterId: str(64),
  department: str(80),
  targetDepartment: str(80),
  priority: { type: String, enum: PRIORITY, default: 'Medium' },
  status: { type: String, enum: ['Pending', 'Accepted', 'Needs clarification', 'Declined'], default: 'Pending' },
  description: str(8000),
  due: date, created: date,
  assigneeId: str(64),
  taskId: str(64),
  links: str(2000),
});

const Meeting = define('Meeting', {
  title: str(200, { required: true }), date, time: str(10), department: str(80), notes: str(4000), hostId: str(64),
});

const Document = define('Document', {
  title: str(200, { required: true }), projectId: str(64), body: str(50000), updated: date, createdBy: str(64),
});

const Goal = define('Goal', {
  title: str(200, { required: true }), progress: { type: Number, min: 0, max: 100, default: 0 }, owner: str(80), target: str(80),
});

const Automation = define('Automation', { label: str(200, { required: true }), enabled: { type: Boolean, default: true } });

const Onboarding = define('Onboarding', {
  profileId: str(64), kind: { type: String, enum: ['AI', 'Human'], default: 'Human' },
  name: str(120, { required: true }), jobTitle: str(160), department: str(80), leadId: str(64), duties: str(4000),
  aiActsAsLead: { type: Boolean, default: false },
  stage: { type: String, enum: ['Awaiting team lead', 'Collecting requirements', 'Awaiting employer approval', 'Active'], default: 'Awaiting team lead' },
  created: date,
  requirements: { type: [Mixed], default: [] },
  history: { type: [Mixed], default: [] },
});

const Activity = define('Activity', {
  name: str(120), action: str(500), type: str(40), at: str(40), actorId: str(64),
  when: { type: Date, default: Date.now },
});

const Company = define('Company', {
  name: str(120, { required: true }), legalName: str(160), tagline: str(160), industry: str(80), size: str(40),
  founded: { type: String, default: '', match: /^(\d{4})?$/ }, headquarters: str(120),
  website: { type: String, default: '', trim: true, maxlength: 200, match: /^(https?:\/\/\S+)?$/i },
  email: { type: String, default: '', trim: true, maxlength: 200, match: /^([^\s@]+@[^\s@]+\.[^\s@]+)?$/ },
  phone: str(40), timezone: str(60), workweek: str(80), currency: str(8), mission: str(600), description: str(3000),
  values: { type: [{ type: String, trim: true, maxlength: 60 }], default: [], validate: [(v) => v.length <= 8, 'At most 8 values'] },
});

const Settings = define('Settings', {
  approvals: { type: Boolean, default: true }, audit: { type: Boolean, default: true }, alerts: { type: Boolean, default: true },
});

module.exports = { User, Project, Task, Request, Meeting, Document, Goal, Automation, Onboarding, Activity, Settings, Company, ROLES };
