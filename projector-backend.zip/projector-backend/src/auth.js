'use strict';
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const config = require('./config');
const { User } = require('./models');
const { HttpError, wrap } = require('./errors');

const sign = (user) => jwt.sign({ sub: user.id, role: user.role }, config.jwtSecret, { expiresIn: config.jwtExpires });

/** Verifies the bearer token and loads the current user (so role/active changes apply immediately). */
const requireAuth = wrap(async (req, _res, next) => {
  const header = req.get('authorization') || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  if (!token) throw new HttpError(401, 'Sign in to continue.');
  let payload;
  try { payload = jwt.verify(token, config.jwtSecret); } catch { throw new HttpError(401, 'Your session has expired. Please sign in again.'); }
  const user = await User.findOne({ id: String(payload.sub) });
  if (!user || !user.active) throw new HttpError(401, 'This account is not active.');
  req.user = user;
  next();
});

const requireRole = (...roles) => (req, _res, next) => (roles.includes(req.user.role) ? next() : next(new HttpError(403, 'You do not have permission for this action.')));

const router = express.Router();
const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many sign-in attempts. Try again in a few minutes.' } });

router.post('/login', loginLimiter, wrap(async (req, res) => {
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  if (!email || !password) throw new HttpError(400, 'Email and password are required.');
  const user = await User.findOne({ email });
  // Same message for unknown email / wrong password to avoid account enumeration.
  const ok = user && user.passwordHash && await bcrypt.compare(password, user.passwordHash);
  if (!ok) throw new HttpError(401, 'Incorrect email or password.');
  if (!user.active) throw new HttpError(403, 'This account has not been activated yet.');
  res.json({ token: sign(user), user });
}));

router.get('/me', requireAuth, (req, res) => res.json({ user: req.user }));

router.post('/password', requireAuth, wrap(async (req, res) => {
  const current = String(req.body?.current || '');
  const next = String(req.body?.next || '');
  if (next.length < 8) throw new HttpError(400, 'The new password must be at least 8 characters.');
  if (!(await bcrypt.compare(current, req.user.passwordHash || ''))) throw new HttpError(400, 'Your current password is incorrect.');
  req.user.passwordHash = await bcrypt.hash(next, config.bcryptRounds);
  await req.user.save();
  res.json({ ok: true });
}));

module.exports = { router, requireAuth, requireRole, sign };
