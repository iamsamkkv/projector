'use strict';
// Usage: npm run seed            -> wipes and re-seeds the database with the sample workspace
const mongoose = require('mongoose');
const config = require('../config');
const { seedDatabase } = require('./seed');

(async () => {
  await mongoose.connect(config.mongoUri);
  const r = await seedDatabase({ drop: true });
  console.log(`Seeded ${r.people} people and ${r.tasks} tasks into ${config.mongoUri}`);
  console.log(`All sample accounts use the password from DEFAULT_PASSWORD (currently "${config.defaultPassword}").`);
  await mongoose.disconnect();
})().catch((e) => { console.error(e); process.exit(1); });
