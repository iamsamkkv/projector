'use strict';
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const config = require('../config');
const models = require('../models');

const DATA = JSON.parse(fs.readFileSync(path.join(__dirname, 'data.json'), 'utf8'));
const MODEL_FOR = {
  people: models.User, projects: models.Project, tasks: models.Task, requests: models.Request,
  meetings: models.Meeting, documents: models.Document, goals: models.Goal, automation: models.Automation,
  onboardings: models.Onboarding, activity: models.Activity,
};

/** Seed dates are stored as {"$day": offset} so the demo always looks current. */
function resolveDates(value) {
  if (Array.isArray(value)) return value.map(resolveDates);
  if (value && typeof value === 'object') {
    if (Object.keys(value).length === 1 && typeof value.$day === 'number') {
      const d = new Date(); d.setDate(d.getDate() + value.$day);
      return d.toISOString().slice(0, 10);
    }
    return Object.fromEntries(Object.entries(value).map(([k, v]) => [k, resolveDates(v)]));
  }
  return value;
}

async function seedDatabase({ drop = false } = {}) {
  if (drop) {
    await Promise.all([...Object.values(MODEL_FOR), models.Settings, models.Company].map((M) => M.deleteMany({})));
  }
  const data = resolveDates(DATA);
  const hash = await bcrypt.hash(config.defaultPassword, config.bcryptRounds);
  const minutesAgo = { 0: 9, 1: 23, 2: 42 };
  for (const [name, Model] of Object.entries(MODEL_FOR)) {
    let rows = data[name] || [];
    if (name === 'people') rows = rows.map((p) => ({ ...p, passwordHash: hash }));
    if (name === 'activity') rows = rows.map((a, i) => ({ ...a, when: new Date(Date.now() - (minutesAgo[i] ?? i * 30) * 60000) }));
    if (rows.length) await Model.insertMany(rows, { ordered: true });
  }
  await models.Settings.create({ id: 'workspace', ...(data.settings || {}) });
  await models.Company.create({ id: 'company', ...(data.company || { name: 'Our company' }) });
  return { people: data.people.length, tasks: data.tasks.length };
}

async function seedIfEmpty() {
  if (await models.User.estimatedDocumentCount()) return false;
  const r = await seedDatabase();
  console.log(`[seed] Empty database — seeded ${r.people} people and ${r.tasks} tasks.`);
  return true;
}

module.exports = { seedDatabase, seedIfEmpty };
