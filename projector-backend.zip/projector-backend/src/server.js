'use strict';
const mongoose = require('mongoose');
const config = require('./config');
const { createApp } = require('./app');
const { seedIfEmpty } = require('./seed/seed');

async function main() {
  await mongoose.connect(config.mongoUri);
  console.log(`[db] Connected to ${config.mongoUri.replace(/\/\/[^@]*@/, '//***@')}`);
  await Promise.all(Object.values(mongoose.models).map((m) => m.init()));
  if (config.seedOnEmpty) await seedIfEmpty();
  const server = createApp().listen(config.port, () => console.log(`[api] Projector running on http://localhost:${config.port}`));
  const stop = () => server.close(() => mongoose.disconnect().then(() => process.exit(0)));
  process.on('SIGINT', stop); process.on('SIGTERM', stop);
}

main().catch((e) => { console.error(e); process.exit(1); });
