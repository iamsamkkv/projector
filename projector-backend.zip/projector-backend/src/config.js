'use strict';
require('dotenv').config();
const crypto = require('crypto');

const env = process.env.NODE_ENV || 'development';
const isProd = env === 'production';

let jwtSecret = process.env.JWT_SECRET;
if (!jwtSecret) {
  if (isProd) throw new Error('JWT_SECRET must be set in production.');
  jwtSecret = crypto.randomBytes(32).toString('hex');
  console.warn('[config] JWT_SECRET not set — using a random secret; sessions reset on restart.');
}

module.exports = {
  env,
  isProd,
  port: Number(process.env.PORT) || 4000,
  mongoUri: process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/projector',
  jwtSecret,
  jwtExpires: process.env.JWT_EXPIRES || '8h',
  // Password given to seeded accounts and to accounts created by administrators.
  defaultPassword: process.env.DEFAULT_PASSWORD || 'projector123',
  corsOrigin: process.env.CORS_ORIGIN || '', // comma-separated list; empty = same-origin only
  allowDemoReset: process.env.ALLOW_DEMO_RESET ? process.env.ALLOW_DEMO_RESET === 'true' : !isProd,
  seedOnEmpty: process.env.SEED_ON_EMPTY ? process.env.SEED_ON_EMPTY === 'true' : true,
  bcryptRounds: Number(process.env.BCRYPT_ROUNDS) || 10,
};
